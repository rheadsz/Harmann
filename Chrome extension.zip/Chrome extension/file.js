// chrome://extensions/
var save = document.getElementById("input-btn");
var inputEl = document.getElementById("input-el");
var ulEl = document.getElementById("ul-el");

var myLeads = [];   //stores the links


//adds the links to array
save.addEventListener("click", function(){
    myLeads.push(inputEl.value);  //adds the value of the input element into myLeads array
    inputEl.value = "";             //clears the put field
    renderLeads();
})

function renderLeads(){
    var listItems = "";
    //loops through the myLeads array
    for(var i=0; i< myLeads.length; i++){
        listItems += `
        <li>
            <a href="${myLeads[i]}" target="_blank">
            ${myLeads[i]}
            </a>
        </li> `
        
        //ulEl.innerHTML += "<li>"+ myLeads[i] + "</li> ";
        //alternative to the above line
        /*var lis = document.createElement("li");   -> create element
        lis.innerHTML = myLeads[i];     ->setting li value
        ulEl.append(lis);         ->append to ul    */

    }
    ulEl.innerHTML = listItems;
}

